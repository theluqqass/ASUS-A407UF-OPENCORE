# For educational purposes only
# X407U
# Currently running in Monterey (Version 12.4)
X407U Configurations

Full Specs:

- Intel Core i3 7020U mobile
- Intel HD 620
- 8G RAM
- Sound ALC 256
- Touchpad I2C
- SSD Samsung 250GB

Working:
- QE/CI 
- Audio out
- Mic in 
- Touchpad
- Battery Stats
- Shutdown, Restart, Sleep, Wake with close & open LID
- USB 3.0
- HDMI + Audio

Not Working:
- Bluetooth
- Nvidia optimus (disabled)
- Cardreader
- iMess, FaceTime, etc
